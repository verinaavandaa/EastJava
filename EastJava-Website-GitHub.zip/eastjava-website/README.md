# EastJava — The Living Heritage of East Java

Website edukasi budaya Jawa Timur berbasis HTML, CSS, dan JavaScript. Bisa dipublikasikan gratis dengan GitHub Pages.

## Cara menjalankan
1. Ekstrak ZIP ini.
2. Buka `index.html` di browser untuk melihat website.
3. Untuk GitHub Pages, unggah semua isi folder (bukan folder ZIP-nya) ke repository GitHub.

## Fitur yang sudah tersedia
- Navigasi dan kategori budaya.
- Peta ilustratif dengan titik wilayah yang dapat dipilih.
- Kuis bertingkat Easy, Medium, Hard dengan skor dan pembahasan.
- Culture Comparison.
- My Collection menggunakan localStorage.
- Culture of the Day.
- Cerita dari Daerah dengan penyimpanan lokal.
- Culture Calendar dengan agenda contoh.

## Catatan penting
- Peta pada versi ini adalah ilustrasi interaktif, bukan peta geografis presisi.
- Data agenda pada kalender adalah contoh edukatif, bukan jadwal acara resmi.
- Cerita yang dikirim dan koleksi tersimpan hanya di browser/perangkat pengguna. Agar cerita dapat dibagikan ke semua pengunjung, diperlukan backend/database, autentikasi, dan moderasi admin.
- Materi budaya dalam versi awal merupakan contoh ringkas. Periksa dan lengkapi sumber tepercaya sebelum dipakai untuk publikasi atau kompetisi.
- Google Fonts memerlukan koneksi internet; jika tidak tersedia, website memakai font cadangan.
